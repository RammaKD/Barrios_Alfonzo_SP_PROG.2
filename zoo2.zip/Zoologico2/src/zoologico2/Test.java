package zoologico2;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import modelo.Animal;
import modelo.TipoAlimentacion;
import modelo.Zoologico;
import servicio.Serializadora;
import servicio.ZoologicoService;

public class Test {

    public static void main(String[] args) {
        Zoologico<Animal> zoo = new Zoologico<>();
        
        zoo.agregar(new Animal(1, "Leon", "Panthera leo", TipoAlimentacion.CARNIVORO));
        zoo.agregar(new Animal(2, "Elefante", "Loxodonta", TipoAlimentacion.HERBIVORO));
        zoo.agregar(new Animal(3, "Oso", "Ursus arctos", TipoAlimentacion.OMNIVORO));
        zoo.agregar(new Animal(4, "Zorro", "Vulpes vulpes", TipoAlimentacion.CARNIVORO));
        zoo.agregar(new Animal(5, "Gorila", "Gorilla gorilla", TipoAlimentacion.OMNIVORO));
        
        // Mostrar todos los animales en el zoológico
        zoo.mostrarContenido();
        
        // Filtrar animales por tipo de alimentación CARNIVORO
        System.out.println("\nAnimales CARNIVOROS:");
        zoo.filtrar(a -> a.getTipoAlimentacion().equals(TipoAlimentacion.CARNIVORO))
                .forEach(animal -> System.out.println(animal));
        
        // Filtrar animales cuyo nombre contiene "León"
        System.out.println("\nAnimales cuyo nombre contiene 'Leon':");       
        zoo.filtrar(a -> a.getNombre() == "Leon")
        .forEach(animal -> System.out.println(animal));
        
        

        // Ordenar animales de manera natural (por id)
        System.out.println("\nAnimales ordenados de manera natural (por id):");
        zoo.ordenar(null);
        zoo.paraCadaElemento(animal -> System.out.println(animal));
        
        
        // Ordenar animales por un criterio (nombre):
        System.out.println("\nAnimales ordenados por nombre:");
        zoo.ordenar((a1, a2) -> {
        if (a1 instanceof Animal && a2 instanceof Animal) {
            return ((Animal) a1).getNombre().compareTo(((Animal) a2).getNombre());
        }
        return 0; 
        });
        zoo.paraCadaElemento(animal -> System.out.println(animal));
        
        
        // Guardar el zoológico en un archivo binario
        //List<Animal> animales = zoo.filtrar(a -> true);
        //Serializadora.guardarEnArchivo(animales, "src/data/animales.dat");
        
        // Cargar el zoológico desde el archivo binario
        List<Animal> animalesCargadosBin = new ArrayList<>();
        animalesCargadosBin = Serializadora.cargarDesdeArchivo("src/data/animales.dat");
        System.out.println("\nAnimales cargados desde archivo binario:");
        animalesCargadosBin.forEach(a -> System.out.println(a));
        
        // Guardar el zoológico en un archivo CSV
        //ZoologicoService.guardarCSV(animales, "src/data/animales.csv");
        
        // Cargar el zoológico desde el archivo CSV
        List<Animal> animalesCargadosCSV = new ArrayList<>();
        animalesCargadosCSV = ZoologicoService.cargarDesdeCSV("src/data/animales.csv");
        System.out.println("\nAnimales cargados desde archivo CSV:");
        animalesCargadosCSV.forEach(a -> System.out.println(a));
                
        
        
    }
}
  
        
    

    

