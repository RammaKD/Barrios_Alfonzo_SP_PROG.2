package modelo;

import java.io.Serializable;

public class Animal implements Comparable<Animal>, CSVSerializable, Serializable{
    private static final long serialVersionUID = 1L;
    private int id;
    private String nombre;
    private String especie;
    private TipoAlimentacion tipoAlimentacion;

    public Animal(int id, String nombre, String especie, TipoAlimentacion tipoAlimentacion) {
        this.id = id;
        this.nombre = nombre;
        this.especie = especie;
        this.tipoAlimentacion = tipoAlimentacion;
    }

    public TipoAlimentacion getTipoAlimentacion() {
        return tipoAlimentacion;
    }

    public String getNombre() {
        return nombre;
    }    
    
    @Override
    public String toCSV() {
        return id + "," + nombre + "," + especie + "," + tipoAlimentacion;
    }

    @Override
    public int compareTo(Animal o) {
        return Integer.compare(id, o.id);
    }
    
    @Override
    public boolean equals(Object o){
        if(o == null){
            return false;
        }
        if(o instanceof Animal a){
            return Integer.compare(id, a.id) == 0;
        }
        if(o instanceof TipoAlimentacion t){
            return tipoAlimentacion.equals(t);
        }
        return false;
    }
    
    @Override
    public String toString() {
        return "Animal{" + "id=" + id + ", nombre=" + nombre + ", especie=" + 
                especie + ", alimentacion=" + tipoAlimentacion + '}';
    }
}
