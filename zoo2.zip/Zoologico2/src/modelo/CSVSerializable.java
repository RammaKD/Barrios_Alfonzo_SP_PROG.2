package modelo;

@FunctionalInterface
public interface CSVSerializable {
    String toCSV();
}
