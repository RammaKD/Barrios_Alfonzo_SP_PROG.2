package modelo;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class Zoologico<T> implements Almacenable<T> {
    
    private List<T> animales = new ArrayList<>();

    private void validarIndex(int index) {
        if (index < 0 || index >= animales.size()) {
            throw new IndexOutOfBoundsException("Indice invalido.");
        }
    }
    
    private Iterator<T> iteradorNatural(){
        List<T> aux = new ArrayList<>(animales);
        aux.sort(null);
        return aux.iterator();
    }
    
    public void mostrarContenido() {
        if(!animales.isEmpty()){
            System.out.println("Contenido del zoologico:");
            Iterator<? extends T> iterador = animales.iterator();
            while (iterador.hasNext()) {
                System.out.println(iterador.next());
        }} else {
            System.out.println("El zoologico esta vacio");
        }
    }
    
    public void ordenar(Comparator<? super T> criterio) {
    if (criterio != null) {
        animales.sort(criterio); 
    } else if (!animales.isEmpty() && animales.get(0) instanceof Comparable) {        
        animales.sort(null); 
    } else {
        throw new RuntimeException("No se puede ordenar: no se proporcionó un criterio y los elementos no son comparables.");
    }
}
    
    @Override
    public void agregar(T item) {
        if (item == null) {
            throw new IllegalArgumentException("No se deben almacenar nulos.");
        }
        animales.add(item);
    }
    @Override
    public T obtener(int indice) {
        validarIndex(indice);
        return animales.get(indice);
    }

    @Override
    public void eliminar(int indice) {
        validarIndex(indice);
        animales.remove(indice);
    }

    @Override
    public int tamanio() {
        return animales.size();
    }

    @Override
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> listaFiltrada = new ArrayList<>();
        for(T item: animales){
            if(criterio.test(item))
                listaFiltrada.add(item);
        }
        return listaFiltrada;
    }

    @Override
    public List<T> filtrarArtesanal(Filtradora<? super T> criterio) {
        List<T> listaFiltrada = new ArrayList<>();
        for(T item : animales){
            if(criterio.filtrar(item)){
                listaFiltrada.add(item);
            }
        }
        return listaFiltrada;
    }

    @Override
    public void paraCadaElemento(Consumer<? super T> accion) {
        for(T item : animales){
            accion.accept(item);
        }
    }

    @Override
    public void porCadaElemento(Consumidora<? super T> tarea) {
        for(T item : animales){
            tarea.usar(item);
        }
    }

    @Override
    public List<T> transformar(Function<? super T, ? extends T> transformacion) {
        List<T> aux = new ArrayList<>();
        for (T item : animales){
            aux.add(transformacion.apply(item));
        }
        return aux;
    }

    @Override
    public Iterator<T> iterator() {
        if(!animales.isEmpty() && animales.get(0) instanceof Comparable){
            return iteradorNatural();
        }
        return animales.iterator();
    }
    
    
}
