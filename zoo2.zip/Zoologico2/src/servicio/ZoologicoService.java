package servicio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import modelo.Animal;
import modelo.TipoAlimentacion;

public class ZoologicoService {
        public static void guardarCSV(List<? extends Animal> lista, String path) {
        File archivo = new File(path);
        try {
            if (archivo.exists()) {
                System.out.println("El archivo ya existe");
            } else {
                archivo.createNewFile();
                System.out.println("Archivo guardado");
            }
        } catch (IOException ex) {
            System.out.println("Ocurrio un error al crear el archivo");            
        }
        
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            bw.write("id,marca,precio,tipo\n");
            for (Animal animal : lista){
                bw.write(animal.toCSV() + "\n");
            }
            
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    public static List<Animal> cargarDesdeCSV(String path){
        List<Animal> toReturn = new ArrayList<>();
        try (BufferedReader bf = new BufferedReader(new FileReader(path))) {
            String linea;
            bf.readLine();
            
            while ((linea = bf.readLine()) != null) {
                if(linea.endsWith("\n")){
                    linea.substring(linea.length() - 1);
                }
                String[] data = linea.split(",");
                
                if(data.length == 4){
                    int id = Integer.parseInt(data[0]);
                    String nombre = data[1];
                    String especie = data[2];
                    TipoAlimentacion tipo = TipoAlimentacion.valueOf(data[3]);
                    Animal a = new Animal(id, nombre, especie, tipo);
                    toReturn.add(a);
                }
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return toReturn;
    }
}

