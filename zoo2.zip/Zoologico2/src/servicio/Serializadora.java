package servicio;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import modelo.Animal;

public class Serializadora {

    public static void guardarEnArchivo(List<? extends Animal> lista, String path) {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path)) {
        }) {
            salida.writeObject(lista);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public static List<Animal> cargarDesdeArchivo(String path) {
        List<Animal> toReturn = new ArrayList<>();
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))) {
            toReturn = (List<Animal>) input.readObject();
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
        return toReturn;
    }
}
